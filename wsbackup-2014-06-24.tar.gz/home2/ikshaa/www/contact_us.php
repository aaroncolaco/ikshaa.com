
<?php 

if($_REQUEST['submit']=="Submit")
{
////// Mail ////////////
ini_set("include_path", "."); 
//$mail->PluginDir = "/home/lifelineintl/www"; 
 require("class.phpmailer.php"); 

$sleeptmp = 0; 

// While Loop to send emails 

			$msg.= "<HTML><HEAD><TITLE>Ikshaa :: Enquiry Form </TITLE></HEAD>";
			$msg.="<BODY>";
			$msg.= " <b>First Name :</b> ".$_POST['fname']."<br><br>";
			$msg.= " <b>Last Name :</b> " .$_POST['lname']."<br><br>";
			$msg.= " <b>Email :</b> " .$_POST['email']."<br><br>";
			$msg.= " <b>Tel(Landline) :</b> " .$_POST['pcode1']." " .$_POST['pcode2']." " .$_POST['phone']."<br><br>";
			$msg.= " <b>Tel(Mobile) :</b> " .$_POST['mcode']." " .$_POST['mobile']."<br><br>";
			$msg.= " <b>Company Name :</b> " .$_POST['company_name']."<br><br>";
			$msg.= " <b>Designation :</b> " .$_POST['designation']."<br><br>";
			$msg.= " <b>Message :</b> " .$_POST['comment']."<br><br>";
			$msg.= "</BODY></HTML>";

$subject = "Ikshaa :: Enquiry Form from website  "; 
$content = " "; 
$mail = new phpmailer(); 
$mail->IsSMTP(); 
$mail->Mailer = "smtp"; 
$mail->Host = "127.0.0.1"; 
$mail->WordWrap = 50; 
$mail->IsHTML(true); 
$mail->Subject = $subject; 
$mail->Body = $msg; 
$mail->AltBody = $content; 

$mail->From =$_POST['email'] ;
$mail->FromName =$_POST['fname']; 



 $mail->AddAddress("nyaragoa@gmail.com");
 $mail->AddBCc("cutekaren24@gmail.com");
 $mail->AddBCc("joel@rubiq.in");
//$mail->AddBCc("karen.rodrigues@goacyberworks.com");

if($mail->Send()) 
{ 
$msg1= "<div align='center' style='margin-left:80px;'><font color='#FF0000'>Thank you for your enquiry. We will get back to you soon</font></div>";

}
else
{
$msg1= "<div align='center' style='margin-left:80px;'><font color='#FF0000'>Mailer Error: " . $mail->ErrorInfo."</font></div>"; 

} 
flush(); 
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?
include("include/config.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ikshaa : Contact Us</title>
<link href="css/style.css" type="text/css" rel="stylesheet">
<link href="css/style2.css" type="text/css" rel="stylesheet">

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
 
$(document).ready(function(){
 
	$(document).ready(function () {
		$('#page_effect').fadeIn(2000);
      });
 
});
</script>
<!--[if IE 6]>
<style type="text/css">
body,img, div, h1, h2, h3, h4,fieldset { 
	behavior: url(iepngfix.htc);
}
</style>
<![endif]-->

<!--[if lte IE 6]>

	<link href="css/ie6.css" rel="stylesheet" type="text/css" />

<![endif]-->
<!--[if IE 7]>

	<link href="css/ie7.css" rel="stylesheet" type="text/css" />

<![endif]-->

	<style type="text/css">
.form-div {

 margin-bottom:-5px;
}

.form-div .submit {
  margin-top: 0px;
   border: 1px #826839 solid;
 background-color: #6E4F22;
 width: 100px;
 color:#FFFFFF;
 float:left; margin-left:210px;
 margin-bottom:5px;
}

.form-div .label {
  display: block;
  float: left;
  width: 135px;
  text-align: right;
  margin-right: 5px;
  color: #FFFFFF;
}

.form-div .form-row {
  padding: 4px 0;
  clear: both;
}


.form-div label.error {
  
  display: block;
  padding-left:10px;
  color: red;
 
}

.form-div input, select, textarea {
  width: 230px;
  float: left;
  border: 1px #6E4F22 solid;
  background-color:#C5AC7F;
}

.form-div textarea {
  height: 50px;
}
	


    </style>
<style>


html, body{
	padding: 0px;
	margin: 0px;
	height:110%;
}

body{
background:url(images/test.jpg) no-repeat fixed center top;
}

/* using the child selector (which IE<7 doesn't recognise) to hide the following body css from IE6 and earlier */
html>body {
	background: url(images/test.jpg) no-repeat fixed center top #907747;
	

}

#footer {
	position:absolute;
	bottom:0;
	width:100%;
	height:49px;background-color:#826839;
	/*z-index:999;*/
}

html>body #footer{position:fixed}/* for moz/opera and others*/

#footer-inner {
	height: 27px;
	background-color:#826839;
}





p {margin-top:0}


#inner {
	padding: 0px;
}

#outer>#contain-all>#inner { /* child selector hides from IE<7 */
	/* 
	commented-out the following to prevent #inner from obscuring the navigation 
	menu in IE7.
	Why was #inner obscuring #nav anyway? And why did I give #inner a background
	colour since removing this doesn't seem to break anything in Firefox? 
	*/
	
}

#outer>#contain-all>#inner>#content {
	/* 
	commented-out the following to prevent weird behaviour with the footer image
	in IE7.
	Why did I put the background image in #content in the first place, since 
	removing this doesn't seem to break anything in Firefox? 
	*/
/*	
	background-repeat: no-repeat;
	background-position: bottom right;
	background-attachment: fixed;*/
}





.style1 {color: #FF0000}
.style3 {color: #FF0000; font-size: 9px; }
</style>
<!--[if lte IE 6]>

	<link href="css/ie6.css" rel="stylesheet" type="text/css" />

<![endif]-->
<!--[if IE 7]>

	<link href="css/ie7.css" rel="stylesheet" type="text/css" />

<![endif]-->
<script language="javascript" type="text/javascript">

function val()
{
var minLength = 7; // Minimum length
var minLength1 = 10; // Minimum length

if (document.form.fname.value=="")
    {
     alert("Please enter your First name");
     document.form.fname.focus();
     return false;
    }
	
if (document.form.lname.value=="")
    {
     alert("Please enter your Last name");
     document.form.lname.focus();
     return false;
    }
	
if (document.form.email.value==""){
		alert("Please Enter your Email");
		document.form.email.focus();
		return false;
	}
	else if (!checkEmail(document.form.email.value)){
		document.form.email.focus();
		return false;
	}
		
	
if (document.getElementById("pcode1").value == "") {
alert("Country Code for Tel(Landline) must not be empty!");
document.form.pcode1.focus();
		return false;
} else if (!document.getElementById("pcode1").value.match(/^\d+$/)) {
alert("Country Code for Tel(Landline) must be number");
document.form.pcode1.focus();
		return false;
} 

if (document.getElementById("pcode2").value == "") {
alert("Area Code for Tel(Landline) must not be empty!");
document.form.pcode2.focus();
		return false;
} else if (!document.getElementById("pcode2").value.match(/^\d+$/)) {
alert("Area Code for Tel(Landline) must be number");
document.form.pcode2.focus();
		return false;
}

if (document.getElementById("phone").value == "") {
alert("Landline number must not be empty!");
document.form.phone.focus();
		return false;
} else if (!document.getElementById("phone").value.match(/^\d+$/)) {
alert("Landline must be number");
document.form.phone.focus();
		return false;
		
}
else if (document.form.phone.value.length < minLength) {
alert('Landline number must be at least ' + minLength + ' numbers.');
return false;
}

if (document.getElementById("mcode").value == "") {
alert("Country Code for Tel(Mobile) must not be empty!");
document.form.mcode.focus();
		return false;
} else if (!document.getElementById("mcode").value.match(/^\d+$/)) {
alert("Country Code for Tel(Mobile) must be number");
document.form.mcode.focus();
		return false;
}

if (document.getElementById("mobile").value == "") {
alert("Mobile number must not be empty!");
document.form.mobile.focus();
		return false;
} else if (!document.getElementById("mobile").value.match(/^\d+$/)) {
alert("Mobile must be number");
document.form.mobile.focus();
		return false;
}
else if (document.form.mobile.value.length < minLength1) {
alert('Mobile number must be at least ' + minLength1 + ' numbers.');
return false;
}

if (document.form.comment.value=="")
    {
     alert("Please enter your message");
     document.form.comment.focus();
     return false;
    }

}

function checkEmail(strValue)
{
if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form.email.value)){
return (true)
}
alert("Invalid E-mail Address! Please re-enter.")
return (false)
}
</script>
</head>

<body id="body_con">
<div id="page_effect" style="display:none;">
<div id="outer" style="margin-top:0px; top:0;">
<table width="920"  align="center" border="0" cellspacing="0" cellpadding="0">
  <tr valign="top">
    <td width="865" valign="top"><div align="center" style="margin-top:50px;"><img src="images/logo.png" border="0" usemap="#Map"/ ></div></td>
  </tr>
  <tr valign="top">
  <td class="text"  valign="top" >
  
 <div style=" padding-left:25px; padding-right:25px; margin-top:20px;">
  <div class="header">Contact Us</div>
  <table align="left" cellpadding="0" cellspacing="0" border="0">
  <tr valign="top">
<td valign="top" width="651" ><? echo $msg1; ?>
<div align="center" style=" border:1px solid #826839; background-image:url(images/form-bg.png); background-repeat:repeat;
margin-left:150px; height: auto; width:450px">

<div align="left" class="form-div">
 	<form id="form" name="form" method="post" action="contact_us.php" onsubmit="return val();">
    <div class="form-row"><span class="label"> </span>
<div style="margin-left:210px;">Enquiry Form</div>
  		</div>
  		<div class="form-row">
      <span class="label">First Name <span class="style3">*</span></span>
      <input name="fname" type="text" title="First Name">
  		</div>
        <div class="form-row">
      <span class="label">Last Name<span class="style3">*</span></span>
      <input name="lname" type="text" title="Last Name">
      <br/>
      <span class="label1"></span>
  		</div>
  		<div class="form-row">
      <span class="label">E-Mail <span class="style3">*</span></span>
      <input name="email" type="text" title="Email Id">
  		</div>
        <div class="form-row">
      <span class="label">Tel(Landline) <span class="style3">*</span> +</span>
      <input title="Country Code" name="pcode1" id="pcode1"  maxlength="4" style="width:33px" type="text"><input id="pcode2" maxlength="4" title="Area Code" name="pcode2" style="width:33px" type="text"><input title="Phone number" id="phone" maxlength="12" style="width:155px" name="phone" type="text">
  		</div>
        <div class="form-row">
      <span class="label">Tel(Mobile) <span class="style3">*</span> +</span>
      <input title="Country Code" id="mcode" name="mcode" maxlength="4"  style="width:33px" type="text"><input style="width:193px" maxlength="10" title="Mobile number" name="mobile" id="mobile" type="text">
  		</div>
         <div class="form-row">
      <span class="label">Company Name&nbsp;&nbsp;&nbsp;</span>
      <input name="company_name" type="text" title="Company Name">
  		</div>
        <div class="form-row">
      <span class="label">Designation&nbsp;&nbsp;&nbsp;</span>
      <input name="designation" type="text" title="Designation">
  		</div>
  		<div class="form-row">
      <span class="label">Message <span class="style3">*</span></span>
      <textarea name="comment" title="Message"></textarea>
  		</div>
  		<div class="form-row">
      <input class="submit" value="Submit" type="submit" name="submit" >
  		</div>
 	</form>
</div></div>
</td>
  </tr>
  <!--<tr>
  <td valign="top"><? //$query1="SELECT * FROM pages where page_id='6'";
//$result1 = mysql_query ($query1);
//if(mysql_num_rows($result1))
///{
//while ($row1 = mysql_fetch_array($result1)) {
   ?>
	<?//=$row1['page_content']?>
<? 
//}
//}
//else
//{
//echo "No data available";
//}
?></td>
  </tr> -->
  </table>

</div>

  </td>
  </tr>
</table>
<div style="height:50px;"></div>
</div>

<div id="footer">
<div id="footer-inner">	
<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr><td valign="top" colspan="3"><div id="nav_bar">
	<ul id="nav">
		<li id="nav_hom"><a href="index.php">Home</a></li>
        <li class="sep">|</li>
		<li id="nav_abt"><a href="about_us.php">About ikshaa</a></li>
		<li class="sep">|</li>
        <li id="nav_fac"><a href="facilities_and_location.php">Facilities & Location</a></li>
		 <li class="sep">|</li>
        <li id="nav_gal"><a href="gallery.php">Photo Gallery</a></li>
        <li class="sep">|</li>
        <li id="nav_con"><a href="contact_us.php">Contact Us</a></li>
		</ul>
	</div>
	</td></tr>
    <tr valign="top">
    <td valign="top"></td>
    <td align="center" valign="middle" width="950" class="footer">Copyright &copy; Ikshaa. All Rights Reserved
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Served by <a class="ftr" target="_blank" href="http://www.goacyberworks.com/">GCW</a>
    </td>
    <td valign="top"></td>
  </tr></table>
</div></div>
</div>
<map name="Map" id="Map"><area shape="rect" coords="2,3,244,92" href="index.php" />
</map></body>
</html>
