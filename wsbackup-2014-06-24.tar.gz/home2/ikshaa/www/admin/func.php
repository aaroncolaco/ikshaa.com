<?
function getVal($a){
	if($_POST[$a]){
		$ret=$_POST[$a];
	}
	else{
		$ret=$_GET[$a];
	}
	return $ret;
}
	function Validate(){
		$this->owner_id="";
		$this->status="";
		$sql="select * from ".TABLE_PREFIX."owner_mst where userid='".EscapeString($this->userid)."' and password='".md5(EscapeString($this->password))."'";
		if ($result=mysql_query($sql)){
			$rows=mysql_fetch_array($result);
			$ownerid=$rows[owner_id];
			$this->status=$rows[status];
			mysql_free_result($result);	
		}
		if($this->status !=""){

                if($this->status=="A" or $this->status=="F"){
                    $this->owner_id=$ownerid;
                    $msg="Your status is Active";
    				$_SESSION['owner_id']=$ownerid;
    				$_SESSION['OwnerActive'] = TRUE;
    			}
    			elseif($this->status=="P"){
    				$_SESSION['owner_id']=$ownerid;
                    $msg="Your status is Pending.";
    				$_SESSION['OwnerNoPaid'] = TRUE;
    			}
    			elseif($this->status=="S"){
    				$_SESSION['OwnerNoPaid'] = TRUE;
                    $msg="Your account is Suspended. Please contact administrator for further details.";
    			}
    			elseif($this->status=="D"){
                    $_SESSION['OwnerNoPaid'] = TRUE;
    				$msg="Your account is Disabled. Please contact administrator for further details.";
    			}
      
		}else{
			$msg="Login name and password mismatch. Please try again with valid login name password";
		}
		
		return $msg;
	}
function EscapeString($text){
    //$text = htmlentities($text,ENT_NOQUOTES ,"".CHARSET."");
    if (!get_magic_quotes_gpc()) {
        $text = mysql_real_escape_string($text);
    }
    return $text;

}
function escape_quote($str) 
{
	return ereg_replace("(')", "&#39;", $str);
}
?>