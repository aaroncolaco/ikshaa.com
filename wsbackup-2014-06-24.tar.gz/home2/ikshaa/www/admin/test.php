<?
include "include/config.php";
require_once "include/functions.php";
?>
<?
$row = Query("SELECT title FROM gallery group by title") or die (mysql_error());

while($row1 = mysql_fetch_array($row))
{
?>
<div align='center'><?=$row1['title']?></div>
<?
 	$sql_result=Query("SELECT * FROM `gallery` where title='".$row1['title']."' order by title ASC");
while($rows = mysql_fetch_array($sql_result))
{ 
?>
<div align='center'><img src='../images/gallery/thumb/<?=$rows['image']?>'/></div><?
}

 }
 ?>

