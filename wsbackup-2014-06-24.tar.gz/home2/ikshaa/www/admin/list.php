<?php 
require_once "include/functions.php";
sessionCheck();
//include_once "admin_templates/header.php"; 
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Sunshine Worldwide School :: Taking healing to nations : Admin Panel</title>
<link href="css/style.css" type="text/css" rel="stylesheet"><link href="../css/style.css" type="text/css" rel="stylesheet">
  <script type="text/javascript">

function ShowHide(elementId)
{
	var element = document.getElementById(elementId);
	if(element.style.display != "block")
	{
		element.style.display = "block";
	}
	else
	{
		element.style.display = "none";
	}
}

</script>
  <style type="text/css">
<!--
.style2 {
	color: #006600;
	font-size: 24px;
}
.style3 {font-size: 12px}
.style5 {font-size: 12px; font-weight: bold; }
.style6 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
  </style>
</head>

<body style="margin: 10px 0px 0px 0px; padding:0px; ">
<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr valign="top">
<td valign="top" width="971" bgcolor="#FFFFFF">
<table border="0" cellspacing="0" cellpadding="0" width="971">
  <tr valign="top">
    <td  align="center" valign="top" class="hr1">
	
	</td>
  </tr>
  <tr valign="top">
    <td valign="top">
	  <table cellpadding="0" cellspacing="0" border="0">
	  <tr><td colspan="2"><div align="center" style="float:left; margin-left:200px; "><img src="../images/logo.jpg"></div>
	  <div class="r-txt style2" style="float:right; margin-right:200px; margin-top:80px ">Sunshine Worldwide School, Goa</div>
	  </td>
	  </tr>
<tr><td colspan="2"  height="13" background="../images/m-bt.jpg" style="background-repeat:repeat-x; "></td></tr>
  <tr>
    <td width="160" valign="top" align="center" style="padding-top:1px; padding-bottom:8px " ><? include('menu.php');?></td>
    <td width="811" align="center" valign="top" class="text"><br>

	<?
	if($_GET['action']=="aboutus")
	{
	echo"<table width='698' border='0' align='center' cellpadding='0' cellspacing='1' bgcolor='#FFFFFF'>
  <tr bgcolor='#003366'>
    <td width='586' height='35' align='center' valign='middle'><span class='style6'>TITLE</span></td>
    <td width='112' align='center' valign='middle'><span class='style6'>ACTION</span></td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td colspan='2' height='30' align='left' valign='middle' bgcolor='#CCCCCC' style='padding-left:20px '><span class='style5'>About Sunshine </span></td>
</td>
  </tr>
    <tr bgcolor='#DDDDDD'>
    <td height='30' align='left' valign='middle' style='padding-left:20px '>&nbsp;&nbsp;Our Mission</td>
    <td align='center' valign='middle'><a href='edit_content.php?id=2' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> 
</td>
  </tr>
  <tr bgcolor='#DDDDDD'>
    <td height='25' align='left' valign='middle' bgcolor='#DDDDDD' class='style3' style='padding-left:20px '>&nbsp;&nbsp;Sunshine Philosophy</td>
    <td align='center' valign='middle'><a href='edit_content.php?id=16' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> </td>
  </tr>
   <tr bgcolor='#DDDDDD'>
    <td height='25' align='left' valign='middle' bgcolor='#DDDDDD' class='style3' style='padding-left:20px '>&nbsp;&nbsp;Quality Policy</td>
    <td align='center' valign='middle'><a href='edit_content.php?id=17' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> </td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td colspan='2' height='30' align='left' valign='middle' bgcolor='#CCCCCC' class='style5' style='padding-left:20px '>The Creative team </td>

  </tr>
  <tr bgcolor='#DDDDDD'>
    <td height='25' align='left' valign='middle' bgcolor='#DDDDDD' class='style3' style='padding-left:20px '>&nbsp;&nbsp;The Dream team </td>
    <td align='center' valign='middle'><a href='edit_content.php?id=7' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> </td>
  </tr>
  <tr bgcolor='#DDDDDD'>
    <td height='25' align='left' valign='middle' bgcolor='#DDDDDD' style='padding-left:20px '><span class='style3'>&nbsp;&nbsp;The Governing Council </span></td>
    <td align='center' valign='middle'><a href='edit_content.php?id=8' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a></td>
  </tr>
  <tr bgcolor='#DDDDDD'>
    <td height='25' align='left' valign='middle' bgcolor='#DDDDDD' class='style3' style='padding-left:20px '>&nbsp;&nbsp;Members of P.T.A </td>
    <td align='center' valign='middle'><a href='edit_content.php?id=9' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> </td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td height='30' align='left' valign='middle' bgcolor='#CCCCCC' class='style5' style='padding-left:20px '>Sunshine Happenings </td>
    <td align='center' valign='middle'><a href='edit_content.php?id=10' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> </td>
  </tr>
   <tr bgcolor='#EBEBEB'>
    <td height='30' colspan='2' align='left' valign='middle' class='style5' style='padding-left:20px '>&nbsp;&nbsp;<a href='gallery.php' title='View List of Photos'>Photo Gallery</a></td>
	  </tr>
  <tr bgcolor='#CCCCCC'>
    <td height='30' align='left' valign='middle' bgcolor='#CCCCCC' class='style5' style='padding-left:20px '>Parents Page </td>
    <td align='center' valign='middle'><a href='edit_content.php?id=11' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> </td>
  </tr>
    <tr bgcolor='#EBEBEB'>
    <td height='30' colspan='2' align='left' valign='middle' class='style5' style='padding-left:20px '>&nbsp;&nbsp;<a href='pdffile.php?action=list' title='View List of Files'>Upload File</a></td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td height='30' align='left' valign='middle' bgcolor='#CCCCCC' class='style5' style='padding-left:20px '>Looking Ahead </td>
    <td align='center' valign='middle'><a href='edit_content.php?id=12' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> </td>
  </tr>
</table>";
}
	elseif($_GET['action']=="admission")
	{
		echo "<table width='698' border='0' align='center' cellpadding='0' cellspacing='1' bgcolor='#FFFFFF'>
  <tr bgcolor='#003366'>
    <td width='586' height='35' align='center' valign='middle'><span class='style6'>TITLE</span></td>
    <td width='112' align='center' valign='middle'><span class='style6'>ACTION</span></td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td height='30' align='left' valign='middle' bgcolor='#CCCCCC' style='padding-left:20px '><span class='style5'>Admission Procedure </span></td>
    <td align='center' valign='middle'>            <a href='edit_content.php?id=4' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> 
</td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td height='30' align='left' valign='middle' bgcolor='#CCCCCC' class='style5' style='padding-left:20px '>Rules and Regulations </td>
    <td align='center' valign='middle'>            <a href='edit_content.php?id=13' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> 

  </tr>
   <tr bgcolor='#eeeeee'>
    <td height='30' colspan='2' align='left' valign='middle' bgcolor='#eeeeee' class='style5' style='padding-left:20px '><a href='files.php?action=list' title='View List of Files'>Rules and Regulations - Upload File</a></td>

  </tr>
</table>";
	
	}
		elseif($_GET['action']=="affiliates")
	{
		echo "<table width='698' border='0' align='center' cellpadding='0' cellspacing='1' bgcolor='#FFFFFF'>
  <tr bgcolor='#003366'>
    <td width='586' height='35' align='center' valign='middle'><span class='style6'>TITLE</span></td>
    <td width='112' align='center' valign='middle'><span class='style6'>ACTION</span></td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td height='30' align='left' valign='middle' bgcolor='#CCCCCC' style='padding-left:20px '><span class='style5'>IMA</span></td>
    <td align='center' valign='middle'>            <a href='edit_content.php?id=5' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> 
</td>
  </tr>
  <tr bgcolor='#CCCCCC'>
    <td height='30' align='left' valign='middle' bgcolor='#CCCCCC' class='style5' style='padding-left:20px '>Helen O' Grady</td>
    <td align='center' valign='middle'>            <a href='edit_content.php?id=14' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> 

  </tr>
   <tr bgcolor='#CCCCCC'>
    <td height='30' align='left' valign='middle' bgcolor='#CCCCCC' class='style5' style='padding-left:20px '>Wonder Lipi</td>
    <td align='center' valign='middle'>            <a href='edit_content.php?id=15' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a> 

  </tr>
</table>";
	
	}
	?>

	</td>
  </tr>
</table>
	</td>
  </tr>
  <tr><td valign="top" style="background-image: url(../images/ftr-bg.jpg); background-repeat: repeat-x; height:70px ">
	<table width="953" align="center"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="190" height="23" align="left" valign="middle" class="ftr">Copyright � 2009 Sunshine School</td>
    <td width="659" align="center" valign="middle" class="ftr2"></td>
    <td width="104" align="right" valign="middle"class="ftxt1"></td>
  </tr>
</table>
	</td></tr>
</table>
</td>
</tr>

</table>
</body>
</html>

