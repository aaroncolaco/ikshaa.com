<?php 
require_once "include/functions.php";
sessionCheck();
//include_once "admin_templates/header.php"; 
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Ishkaa : Admin Panel</title>
<link href="../css/style.css" type="text/css" rel="stylesheet"><link href="css/style.css" type="text/css" rel="stylesheet">
  <script type="text/javascript">

function ShowHide(elementId)
{
	var element = document.getElementById(elementId);
	if(element.style.display != "block")
	{
		element.style.display = "block";
	}
	else
	{
		element.style.display = "none";
	}
}

</script>
  <style type="text/css">
<!--
.style2 {
	color: #006600;
	font-size: 24px;
}
.style3 {font-size:18px; color: #FEE181; font-family: Arial; margin-left:150px; margin-top:50px;}
-->
  </style>
  <!--[if IE 6]>
<style type="text/css">
body,img, div, h1, h2, h3, h4 { 
	behavior: url(iepngfix.htc);
}
</style>
<![endif]-->
</head>

<body>
<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr valign="top">
<td valign="top" width="971">
<table border="0" cellspacing="0" cellpadding="0" width="971">
  <tr valign="top">
    <td  align="center" valign="top" class="hr1">
	
	</td>
  </tr>
  <tr valign="top">
    <td valign="top">
	  <table cellpadding="0" cellspacing="0" border="0">
	  <tr><td colspan="2"><div align="left" style="margin-left:250px; "><img src="../images/logo.png"></div>
	  </td>
	  </tr>
<tr><td colspan="2"  height="13"></td></tr>
  <tr style=" background-color:#907747">
    <td width="160" valign="top" align="center" style="padding-top:0px; padding-bottom:5px " ><? include('menu.php');?></td>
    <td width="811" align="center" valign="top"><p></p>
      <p>&nbsp;</p>
      <p align="left" class="style3">Welcome to Admin Panel</p></td>
  </tr>
</table>
	</td>
  </tr>
  <tr ><td height="22" valign="top">
	<table width="" align="center"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="" align="center" valign="middle" class="footer">&nbsp;Copyright &copy; Ikshaa. All Rights Reserved&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Served by <a class="ftr" target="_blank" href="http://www.goacyberworks.com/">GCW</a>

    </td>

  </tr>
</table>
	</td></tr>
</table>
</td>
</tr>

</table>
</body>
</html>
