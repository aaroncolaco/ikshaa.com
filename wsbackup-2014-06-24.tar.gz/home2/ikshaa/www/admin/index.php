<?php 
session_start();
require_once 'include/config.php';
require_once "include/functions.php";
if( isset($_SESSION[$SESSION]) ) {
	header("Location: admin.php");
}
if( isset($_POST['submit']) ) {
	
	$user = htmlentities($_POST['txtuser']);
	$pass = htmlentities($_POST['txtpass']);
	
	if($user && $pass){
		$error=sessionStart($user,$pass);
	}else{
		$error = " <p class='errorMessage' ><strong>Invalid Username or Password</strong></p>";
	}
} 
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Iskaa:: Admin Panel</title>
<link href="../css/style.css" type="text/css" rel="stylesheet"><link href="css/style.css" type="text/css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet">

<link rel="shortcut icon" href="favicon.ico" />
<style>
body{margin-top:50px;}
.logintxt{font-family: Arial; font-size:13px; color: #F2E3D4;}

</style>

<script type="text/javascript">
function checkForm() {
	if( !document.login.user.value ) {
		alert("Please Enter User Name");
		document.login.user.focus();
		return false;
	}
	if( !document.login.pass.value ) {
		alert("Please Enter Password");
		document.login.pass.focus();
		return false;
	}
	document.login.submit();	
}
</script>
 <!--[if IE 6]>
<style type="text/css">
body,img, div, h1, h2, h3, h4 { 
	behavior: url(iepngfix.htc);
}
</style>
<![endif]-->
</head>

<body>
<table align="center" border="0" cellspacing="0" cellpadding="0">
<tr valign="top">
<td valign="top" width="971">
<table border="0" cellspacing="0" cellpadding="0" width="971">
  <tr valign="top">
    <td  align="center" valign="top" class="hr1">
	
	</td>
  </tr>
  <tr valign="top">
    <td height="316" valign="top">
	  <table cellpadding="0" cellspacing="0" border="0">
	  <tr><td width="971" colspan="2"><div align="center" style="float:left; margin-left:275px; "><img src="../images/logo.png"></div>
	  </td>
	  </tr>
<tr><td height="204" align="left">
<div align="left" style="margin-right:130px; margin-top:80px;">
<form name="login" action="index.php" method="post" onSubmit="return checkForm();">

          <table width="40%" border="1" align="center" cellpadding="5" cellspacing="2" bordercolor="#6E4F22" style="border-collapse:collapse;">
              <tr bgcolor="" align="center" valign="top" style=" background-color:#907747">
                <td colspan="2"><div align="center" style=" color: #582C2C; font-size:15px; font-family: Arial;"><b>ADMIN CONTROL PANEL</b></div>
   <?php echo $error; ?></td>
              </tr>
              <tr style=" background-color:#907747" >
                <td  width="209" align="right" valign="middle" class="logintxt" ><b>User Name </b></td>
                <td  width="396" align="left" valign="middle"><input name="txtuser" type="text" id="txtuser" value="<?php echo $_POST['txtuser']?>"/></td>
              </tr>
              <tr style=" background-color:#907747">
                <td align="right" valign="middle" class="logintxt"><b>Password </b></td>
                <td align="left" valign="middle"><input name="txtpass" type="password" id="txtpass" /></td>
              </tr>
              <tr style=" background-color:#907747">
                <td colspan="2" align="center">  <input  name="submit" type="submit" onclick="MM_validateForm('User','','R','Password','','R');return document.MM_returnValue" value="Login" />
</td>
              </tr>
          </table>
      
</form></div>
</td></tr>
  
</table>
	</td>
  </tr>
 
</table>
</td>
</tr>

</table>


</body>
</html>
