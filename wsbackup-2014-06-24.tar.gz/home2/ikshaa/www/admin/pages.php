<?php
require_once "../include/functions.php";
sessionCheck();

$query = "SELECT page_id,page_name FROM pages";
$row = Query($query) or die("Unkown Error");
if( @mysql_num_rows($row) ) {
	while( $result = mysql_fetch_assoc($row) ) {
		$pages .= "<a href='edit_pages.php?id=$result[page_id]'target='edit_frame'>{$result[page_name]}</a><br /> <br />";
	}
}
include_once "admin_templates/header.php";
?>
<table width="960" height="599" border="0">
  <tr valign="top">
    <td width="152"><? include_once "menu1.php"; ?></td>
    <td width="809"><iframe name="edit_frame" height="720" width="800" frameborder="0" src="blank.html"></iframe></td>
  </tr>
</table>
<?php include_once "admin_templates/footer.php"; ?>