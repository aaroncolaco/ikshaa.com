<?php 
require_once "../inc/functions.php";
sessionCheck();
$query = "SELECT user_name FROM user WHERE user_id ='". $_SESSION['userId']."' ";
$row = Query($query) or die("Unkown Error");
if( @mysql_num_rows($row) ) {
	$result = mysql_fetch_assoc($row);
	$user = $result['user_name'];
}

if( isset($_POST['edit']) ) {
	$user = addslashes($_POST['txtuser']);
	$pass = addslashes($_POST['txtpass']);
	$cnf_pass = addslashes($_POST['txtcnfpass']);
	if( $pass == $cnf_pass){
		if( $user && $pass ) {
			$query = "UPDATE `user` SET `user_name`='$user',`user_pass`='".md5(escape($pass))."'";
		} elseif( $user ) {
			$query = "UPDATE `user` SET `user_name`='$user'";
		}
		$row = Query($query) or die("Unkown Error");
		if( $row ){
			$msg = "<h2> User Profile Updated</h2>";
		} else { 
			$msg = "<h2> User Profile Updation Failed</h2>";
		}
	} else {
		$msg = "<h2>Password Missmatch</h2>";
	}
}
include_once "admin_templates/header.php";
?>
<div align="center">
<h3> Edit Profile</h3>
<?=$msg;?>
<form id="form1" name="form1" method="post" action="profile.php">
  <table width="457" height="121" border="0">
    <tr>
      <td width="144">User Name
        <label></label></td>
      <td width="247"><input type="text" name="txtuser" id="txtuser" value="<?=$user;?>" /></td>
    </tr>
    <tr>
      <td>Password
        <label></label></td>
      <td><input type="password" name="txtpass" id="txtpass" /></td>
    </tr>
    <tr>
      <td>Confirm Password
        <label></label></td>
      <td><input type="password" name="txtcnfpass" id="txtcnfpass" /></td>
    </tr>
  </table>
  <p>
    <label>
    <input type="submit" name="edit" id="edit" value="Change" />
    </label>
  </p>
</form>
</div>
<?php include_once "admin_templates/footer.php"; ?>