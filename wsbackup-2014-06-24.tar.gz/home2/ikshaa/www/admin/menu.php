<div id="masterdiv">
  <a href="edit_content.php?id=1" class="leftnav">Home</a>
  <a href="edit_aboutus.php" class="leftnav">About Us</a>
  <a href="edit_content.php?id=3" class="leftnav">Facilities & Location</a>
  <a href="gallery.php?page_id=4" class="leftnav">Gallery</a>
<!--  <a href="edit_content.php?id=5" class="leftnav">Antique Store</a>
 <a href="edit_content.php?id=6" class="leftnav">Contact Us</a> --> 
  <a href="mod_pswd.php" class="leftnav">Change Password</a> 
  <a href="logout.php" class="leftnav">Logout</a>
</div>