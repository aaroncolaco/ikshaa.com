<?php 
require_once "include/functions.php";
require_once "include/functions.inc.php";

sessionCheck();
$_SESSION[$SESSION] = $_SERVER['REQUEST_URI'];

// directory where vehicle image files are stored
define("GALLERY_DIR", "images/gallery/");

function dbFetchAssoc($result) {
	return mysql_fetch_assoc($result);
}


function dbNumRows($result) {
	return mysql_num_rows($result);
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Ishkaa : Admin Panel</title>
<link href="../css/style.css" type="text/css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet">

  <style type="text/css">
<!--
.style2 {
	color: #006600;
	font-size: 24px;
}
.style3 {font-size:12px; color: #FEE181; font-family: Arial;}

-->


  </style>
   <!--[if IE 6]>
<style type="text/css">
body,img, div, h1, h2, h3, h4 { 
	behavior: url(iepngfix.htc);
}
</style>
<![endif]-->
</head>

<body style="margin:0px;">
<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr valign="top">
<td valign="top" width="971">
<table width="971" height="421" border="0" cellpadding="0" cellspacing="0">
  <tr valign="top">
    <td  align="center" valign="top" class="hr1">
	
	</td>
  </tr>
  <tr valign="top" >
    <td valign="top">
	  <table width="970" border="0" cellpadding="0" cellspacing="0" >
	  <tr><td colspan="2"><div align="left" style=" margin-left:250px; "><img src="../images/logo.png"></div>
	  </td>
	  </tr>
<tr><td colspan="2"  height="13" ></td></tr>
  <tr style=" background-color:#907747">
    <td width="160" valign="top" align="center" style="padding-top:30px; padding-bottom:8px " ><? include('menu.php');?></td>
    <td width="803" align="center" valign="top" >
		<?
		if ($_REQUEST['actn'] == "del") {
				$sql = "SELECT * FROM gallery WHERE id = {$_REQUEST['id']}";
				$result = Query($sql);		
	while($im=mysql_fetch_array($result)){
	$imagename=$im['image'];
				 unlink("../".GALLERY_DIR."thumb/$imagename");
				unlink("../".GALLERY_DIR."$imagename");
				}
$sql_del="delete from gallery where id='".$_GET['id']."'";
			$res=Query($sql_del);
				echo"<br><br><br>";
			echo "<p align='center' class='errorMessage'>Data has been Deleted Succesfully!!</p>";
echo  "<META HTTP-EQUIV=\"Refresh\" Content=\"1;URL=album.php\">";
			}
		
		
    if ( isset($_REQUEST['a']) ) {
    
        switch ($_REQUEST['a']) {
          case 'add' :
            $header = "NEW IMAGE";
            $hidden = "<input type='hidden' name='add_save' value='1' />";
			echo"  <script language='javascript' type='text/javascript'>
  function val(){
    if(document.gal_frm.album_id.value==''){
		alert('Please select Album name');
		document.gal_frm.album_id.focus();
		return false;
		}
		  if(document.gal_frm.image.value==''){
		alert('Please upload an image');
		document.gal_frm.image.focus();
		return false;
		}
  else return true;
  
  }
  </script>";
            break;
          case 'edit' :
            $header = "EDIT IMAGE";
            //$get_blog = mysql_query("SELECT * FROM blog_posts WHERE post_id = {$_REQUEST['id']}");
            
			$get_accessory_images = "SELECT * FROM gallery WHERE id ='". $_GET['id']."' ";
	$row = Query($get_accessory_images) or die (mysql_error());
			
			if (mysql_num_rows($row)){
              $gal_row = mysql_fetch_object($row);
			  $_POST['id'] = $gal_row->id;
              $curr_image = $gal_row->image;
			  $_POST['page_id'] = $gal_row->page_id;
			  //$_POST['title'] = $gal_row->title;
              $hidden = "<input type='hidden' name='edit_save' value='1' />\n<input type='hidden' name='id' value='{$_REQUEST['id']}' />";
            }
            break;
          
          case 'save' :
						$ar_err = array();
						$_POST = array_map('trim' , $_POST);
						if (isset($_POST["add_save"])) {
							$header = "New Image";
							$hidden = "<input type='hidden' name='add_save' value='1' />";
						} else if (isset($_POST["edit_save"])) {
							$header = "Change Image";
							$hidden = "<input type='hidden' name='edit_save' value='1' />\n<input type='hidden' name='id' value='{$_POST['id']}' />";
						}
					
      
            if ($_FILES['image']['name']) {
              if ($_FILES['image']['type']=="image/jpg" || $_FILES['image']['type']=="image/jpeg" || $_FILES['image']['type']=="image/pjpeg" || $_FILES['image']['type']=="image/gif" || $_FILES['image']['type']=="image/png" || $_FILES['image']['type']=="image/tif" || $_FILES['image']['type']=="image/tiff" ) {
                list($width, $height, $type, $attr) = getimagesize($_FILES['image']['tmp_name']);
                if ( $width <= 750 && $height <= 499  ) {
									$image_name = time()."_".strtolower($_FILES['image']['name']);
                  $image = @move_uploaded_file($_FILES['image']['tmp_name'],  "../".GALLERY_DIR.$image_name);
				 $image = createthumbnail("../".GALLERY_DIR.$image_name, "../".GALLERY_DIR."thumb/" . $image_name, 114);
                  if (!$image){
                    $ar_err[] = "Image could not be uploaded";
                  }
                }else{
                  $ar_err[] = "The image size is too big, please upload another image";
                }
              }else{
                $ar_err[] = "Incorrect Image Format";
              }
            }
			else if (!$_FILES['image']['name']) {
			 $image_name=$curr_image;
			}

            break;
          default :
            echo "invalid request";
            break;
        }
        
        if (count($ar_err)) {
          $msg = addslashes(implode("<br />",$ar_err));
        } else {
          $blog_cat = array();
          if (isset($_POST["add_save"])) {
            //$res_chk = "SELECT image, vehicle_id FROM gallery WHERE LOWER(image)='".strtolower($_POST["name"])."' AND vehicle_id='".strtolower($_POST["vehicle_id"])."' ";
			//$re = Query($res_chk) or die("Unkown Error");
           // $res_chk_rows = mysql_num_rows($re);
           // if (!$res_chk_rows) {
              //for($i=1;$i<=$_POST['blog_cat'];$i++) {
               // if ($_POST['cat'.$i]) $catIds[] = $_POST['cat'.$i];
             // }

             $insert_veh = "INSERT INTO gallery VALUES ('', '".$_POST["page_id"]."', '{$image_name}')"; 
              $res = Query($insert_veh);
              if($res) {
                $msg = "The image was added sucessfully";

              } else {
                $msg = "Error adding image";
              }
            //} else {
              //$msg = "Image with this name already exists";
            //}
          } else if (isset($_POST["edit_save"])) {
		  
            //$res_chk = mysql_query("SELECT post_id FROM blog_posts WHERE LOWER(title)='".strtolower($_POST["title"])."' AND post_id<>{$_POST['id']}");
            //$res_chk_rows = mysql_num_rows($res_chk);
           // if (!$res_chk_rows) {
		$query = "UPDATE `gallery` SET `page_id`='".escape_string($_POST['page_id'])."'".( $image_name ? " , image='{$image_name}'" : "" )." WHERE `id` = '".$_POST['gid']."' ";
	$row = Query($query) or die("Unkown Error");
              if($row) {
                $msg = "The image was updated sucessfully";
                
                //mysql_query("DELETE FROM blog_posts_to_cats WHERE post_id = {$_POST['id']}");
                //for($i=1;$i<=$_POST['blog_cat'];$i++) {
                  //if ($_POST['cat'.$i]) {
                   // $result = mysql_query("INSERT INTO blog_posts_to_cats (post_id, cat_id) VALUES ('{$_POST['id']}', '{$_POST['cat'.$i]}')");
                 // }
                //}
              } else {
                $msg = "Error updating";
              }
            //} else {
              //$msg = "A entry with this title already exists";
            //}
          }
        }
    
      ?>
	  	  <p>&nbsp;</p><p>&nbsp;</p>
     <form action="gallery.php?a=save" method="post" name="gal_frm" id="gal_frm" enctype="multipart/form-data" onSubmit="return val();">
      <div align="left" style=" margin-top:4px;" class="style3"><b><?php echo $header; ?></b></div>
      <br>
      <?
        echo ( $msg ? "<p class='errorMessage' align='center'>{$msg}</p>" : "" );
        if ($res) {
         echo "<meta http-equiv='Refresh' content='2; URL=gallery.php?page_id='".$_POST['page_id']."'>";
        }
      ?>
      <table width="90%" border="1" style=" border-collapse: collapse; " bordercolor="#CCCCCC" align="center" cellpadding="5" cellspacing="1" class="entryTable">
        
		<tr>
          <td width="120" valign="top" class="label">Page</td>
          <td width="763" class="content">
          <select name="page_id">
          <option value="1" <? if($_POST['page_id']=="1"){echo "selected";} else if($_REQUEST['page_id']=="1") {echo "selected";}?>>Home</option>
          <option value="2" <? if($_POST['page_id']=="2"){echo "selected";}else if($_REQUEST['page_id']=="2") {echo "selected";}?>>About Ikshaa</option>
          <option value="4" <? if($_POST['page_id']=="4"){echo "selected";}else if($_REQUEST['page_id']=="4") {echo "selected";}?>>Gallery</option>
          </select>
         <input type="hidden" name="gid" id="gid" value="<? if (isset($_POST['id'])) {echo $_POST['id']; } ?>" /></td>
        </tr>

        <tr>
          <td valign="top" class="label">Image</td>
          <td valign="top" class="content">
           <input name="image" id="image" type="file" size="40"  onkeypress="return onkeyPress(event);" /> 
          <br />(image size should be less than or equal to 750px x 499px)
          <? 
            if ($curr_image) { 
              echo "<p>Current Image <br/><img src='../images/gallery/$curr_image' border='0' /><input name='curr_image' type='hidden' value='{$curr_image}' /></p>"; 
            } elseif (isset($_POST['curr_image'])) { 
              echo "<p>Current Image <br/><img src='../images/gallery/{$_POST['curr_image']}' border='0' /><input name='curr_image' type='hidden' value='{$_POST['curr_image']}' /></p>"; 
            }
          ?>
          </td>
        </tr>
        
        
      </table>
      <p align="center"><?=$hidden?>
        <input type="submit" name="submit" value="Save"  />
        &nbsp;&nbsp;
        <input name="btnCancel" type="button" id="btnCancel" value="Cancel" onclick="history.go(-1);return false;" />
      </p>
    </form>    
	<?
		
	} else {

?>
<? $id=$_REQUEST['page_id'];?>
<p>&nbsp;</p>
    <div align="right" style="padding-right:65px; padding-bottom:0px; ">
    <? if($id=='2') { ?>
    <input name="btnAddType" type="button" id="btnAddType" value="View Content"  onClick="javascript:window.location.href = 'edit_aboutus.php?id=2'" />
    <? } else if($id=='4') { 
	echo " ";
	  } else { ?>
       <input name="btnAddType" type="button" id="btnAddType" value="View Content"  onClick="javascript:window.location.href = 'edit_content.php?id=<?=$id?>'" />
<? } ?> 
      <input name="btnAddType" type="button" id="btnAddType" value="New Image"  onClick="javascript:window.location.href = 'gallery.php?a=add&page_id=<?=$id?>'" />
    </div>
<div align="left" style=" margin-top:4px;" class="style3"><b>List of Images for 
      <? $query = "SELECT * FROM pages WHERE page_id ='$id' ";
$row = Query($query) or die("Unkown Error");			
if( @mysql_num_rows($row) ) {
$result = mysql_fetch_assoc($row);
echo $pageName = $result['page_name'];
}
?></b></div>
<br>

  <table width="397" height="121" cellpadding="5" cellspacing="1" class="entryTable" border="0">
  <tr>
      <td width="323"  height='35' align='center' valign='middle' class="label"><div align="center"><b>Images
      </b></div></td>
      <td width="51"  align='center' valign='middle' class="label"><div align='center'><b>Action</b></div></td>
  </tr>
    <?php
	 
		$sql = "SELECT * FROM gallery where page_id=$id";
	$rowsPerPage = 4;
					$result = Query(getPagingQuery($sql, $rowsPerPage));
							$pagingLink = getPaging("gallery.php", $sql, $rowsPerPage);
							if (dbNumRows($result) > 0) {
								while($row = dbFetchAssoc($result)) {
									extract($row);
									
    ?>
	
	<tr style=" background-color:#E2CA9B; ">
	 <td height='30' align='center' valign='middle' style="padding:5px; "><div align='center'><img src='../images/gallery/thumb/<?=$row['image']?>'/></div>
	 </td>
    <td align='center' valign='middle'>
	<div align='center'>
	<a href='gallery.php?a=edit&id=<?=$row['id']?>' title='Modify'><img src='css/icon_edit.gif' border='0' alt='Modify' /></a>&nbsp;
	<a href='gallery.php?actn=del&id=<?=$row['id']?>' title='Delete'><img src='css/icon_delete.gif' border='0' alt='Delete' onclick="return confirm_msg('Are you sure you want to delete?');" /></a>
</div></td></tr>
	<?php } // end while ?>
<? echo ( $pagingLink ? "<tr><td colspan='2'><div align='center' class='paging'>$pagingLink</div></td></tr>" : "");
							} else {
								echo "<tr><td colspan='2' align='center' class='entryTable'><strong>No Entries</strong></td></tr>";
							} ?> 
	   

</table>
<p>&nbsp;</p>
<? } ?>
	</td>
  </tr>
</table>
	</td>
  </tr>
  <tr ><td height="22" valign="top">
	<table width="" align="center"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="" align="center" valign="middle" class="footer">&nbsp;Copyright &copy; Ikshaa. All Rights Reserved&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Served by <a class="ftr" target="_blank" href="http://www.goacyberworks.com/">GCW</a>

    </td>

  </tr>
</table>
	</td></tr>
</table>
</td>
</tr>

</table>
</body>
</html>
