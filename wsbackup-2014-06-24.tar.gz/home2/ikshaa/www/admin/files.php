<?php 
require_once "include/functions.php";
sessionCheck();
$_SESSION[$SESSION] = $_SERVER['REQUEST_URI'];

function dbQuery($sql) {
	$result = mysql_query($sql);
	return $result;
}

function dbAffectedRows() {
	global $dbConn;
	return mysql_affected_rows($dbConn);
}

function dbFetchArray($result, $resultType = MYSQL_NUM) {
	return mysql_fetch_array($result, $resultType);
}

function dbFetchAssoc($result) {
	return mysql_fetch_assoc($result);
}

function dbFetchRow($result) {
	return mysql_fetch_row($result);
}

function dbFreeResult($result) {
	return mysql_free_result($result);
}

function dbNumRows($result) {
	return mysql_num_rows($result);
}

function dbSelect($dbName) {
	return mysql_select_db($dbName);
}

function dbInsertId() {
	return mysql_insert_id();
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Sunshine Worldwide School :: Taking healing to nations : Admin Panel</title>
<link href="../css/style.css" type="text/css" rel="stylesheet"><link href="css/style.css" type="text/css" rel="stylesheet">
<script language="javascript" type="text/javascript" src="include/common.js"></script>

<script language="javascript" type="text/javascript">
function checkCatForm() {
	with (window.document.frmCat) {
		if (isEmpty(cat_name, 'Enter Category Name')) {
			return;
		} else {
			submit();
		}
	}
}
</script>
  <style type="text/css">
<!--
.style2 {
	color: #006600;
	font-size: 24px;
}
.style3 {
	color: #000000;
	font-weight: bold;
}
-->
  </style>
</head>

<body style="margin: 10px 0px 0px 0px; padding:0px; ">
<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr valign="top">
<td valign="top" width="971" bgcolor="#FFFFFF">
<table border="0" cellspacing="0" cellpadding="0" width="971">
  <tr valign="top">
    <td  align="center" valign="top" class="hr1">
	
	</td>
  </tr>
  <tr valign="top">
    <td valign="top">
	  <table cellpadding="0" cellspacing="0" border="0">
	  <tr><td colspan="2"><div align="center" style="float:left; margin-left:200px; "><img src="../images/logo.jpg"></div>
	  <div class="r-txt style2" style="float:right; margin-right:200px; margin-top:80px ">Sunshine Worldwide School, Goa</div>
	  </td>
	  </tr>
<tr><td colspan="2"  height="13" background="../images/m-bt.jpg" style="background-repeat:repeat-x; "></td></tr>
  <tr>
    <td width="160" valign="top" align="center" style="padding-top:1px; padding-bottom:8px " ><? include('menu.php');?></td>
    <td width="811" align="center" valign="top">
		<?php
		
		
		if ( isset($_REQUEST['a']) ) {
			switch ($_REQUEST['a']) {
				case 'add' :
					$header = "New File";
					$hidden = "<input type='hidden' name='add_save' value='1' />";
					break;
				case 'edit' :
					$header = "Edit File";
					$get_cat = Query("SELECT * FROM files WHERE id = {$_REQUEST['id']}");
					extract(dbFetchAssoc($get_cat));
					$hidden = "<input type='hidden' name='edit_save' value='1' />\n<input type='hidden' name='id' value='$id' />";
					break;
				case 'delete' :
				$sql = "SELECT * FROM files WHERE id = {$_REQUEST['id']}";
				$result = Query($sql);		
	while($im=mysql_fetch_array($result)){
	$file=$im['pdffile'];
				 unlink("../images/files/$file");
				}
					// delete a file
					if (isset($_GET['id']) && (int)$_GET['id'] > 0) {
						$id = (int)$_GET['id'];
					} else {
						// redirect to files.php if id is not present
						echo "<meta http-equiv='Refresh' content='0; URL=files.php'>";
					}
					$result_del_post = Query("DELETE FROM files WHERE id = $id");
					$result_del = Query("DELETE FROM files WHERE id = $id");
					$successMessage = $result_del ? "<p class='errorMessage' align='center'>File has been deleted succesfully!!</p><p class='errorMessage' align='center'>Click <a href='files.php'>Here</a> to List All Files.</p>" : "error";
					echo $successMessage;
					echo "</td></tr></table></body></html>";
					die();
					break;
				case 'save' :
					$ar_err = array();
					$_POST = array_map('trim' , $_POST);
					if (isset($_POST["add_save"])) {
						$header = "New File";
						$hidden = "<input type='hidden' name='add_save' value='1' />";
					} else if (isset($_POST["edit_save"])) {
						$header = "Edit File";
						$hidden = "<input type='hidden' name='edit_save' value='1' />\n<input type='hidden' name='id' value='{$_POST['id']}' />";
					}
					$page = $_POST['page'];
					$name = $_POST['cat_name'];
					
					if (!$name) {
						$ar_err[] = "Name cannot be blank";
					} else if (strlen($name) > 60) {
						$ar_err[] = "Name should be maximum of 60 characters";
					}
					
					if (count($ar_err)) {
						$msg = "<p class='errorMessage' align='center'>".addslashes(implode("<br />",$ar_err))."</p>";
					} else {
						if (isset($_POST["add_save"])) {
						$name=$_POST['cat_name'];
$page="13";
$f=$_FILES['pdffile']['name'];
	$uploaddir = "../images/files/";
		if($_FILES['pdffile']['name'])
				 {   
					move_uploaded_file($_FILES["pdffile"]["tmp_name"], $uploaddir .time()."_".strtolower($_FILES["pdffile"]["name"]));
					$f=$uploaddir . $_FILES["pdffile"]["name"];
					$f= time()."_".strtolower($_FILES["pdffile"]["name"]);
				 }
				 				
	$qry="INSERT INTO files values('','$page','$name','$f')";
						$rs = Query($qry) or die("query failed:".mysql_error()); 
echo "<center><font color='#FF0000'><b>Data has been Saved Succesfully!!</b></font></center>";
						
						} 
						
						else if (isset($_POST["edit_save"])) {
 $id=$_POST['fid'];
 $page="13";					
$name=$_POST['cat_name'];
$file=$_FILES['pdffile']['name'];
$uploaddir = "../images/files/";
if(!empty($file))
				 {   
					move_uploaded_file($_FILES["pdffile"]["tmp_name"], $uploaddir .time()."_".strtolower($_FILES["pdffile"]["name"]));
					$file=$uploaddir .time()."_".strtolower($_FILES["pdffile"]["name"]);
					$file= time()."_".strtolower($_FILES["pdffile"]["name"]);
				 }	
				elseif(empty($file))
				{
				$file=$_POST['f1'];
				}
								  

$query = "UPDATE `files` SET `page`='".$page."', `name`='".$name."', `pdffile`='".$file."' WHERE `id` = '".$id."' ";
	 $row = Query($query) or die("Unkown Error");

if($row)
{
echo"<p class='errorMessage' align='center'>Data has been saved succesfully!!</p>";
}						}
						
					}
					break;
				default :
					echo "invalide request";
					break;
			}
			
		?>
		<form action="files.php?a=save" method="post" name="frmCat" id="frmCat" enctype="multipart/form-data">
		<p align="center" class="formTitle"><?php echo $header; ?></p>
    <?php echo $msg; ?>
		<table width="70%" border="0" align="center" cellpadding="5" cellspacing="1" class="entryTable">
			<tr>
				<td width="120" valign="top" class="label">Name</td>
				<td class="content"><input type="text" value="<?=$name?>" name="cat_name" class="box" size="50" maxlength="60" /></td>
			</tr>
			<tr>
				<td width="120" valign="top" class="label">Upload File</td>
				<td class="content"><input name="pdffile" type="file"><input type="hidden" value="<?=$pdffile?>" name="f1" class="box" size="50" maxlength="60" /></td>
			</tr>
			<tr>
				<td colspan="2" class="label">
				  <? 
				  
            if ($pdffile) { 
              echo "<p>Current File <br/><a href='../images/files/$pdffile' border='0'>".$pdffile."</a><input name='pdffile' type='hidden' value='{$pdffile}' /></p>"; 
            } elseif (isset($pdffile)) { 
              echo "<p>Current File <br/><a href='../images/files/<?=$pdffile?>' target='_blank'>".$pdffile."</a><input name='pdffile' type='hidden' value='{$pdffile}' /></p>"; 
            }
          ?>
</td>
			</tr>
		</table><input type="hidden" value="<?=$id?>" name="fid" class="box" size="50" maxlength="60" />
    <p align="center"><?=$hidden?>
      <input name="btnSave" type="button" id="btnSave" value="Save Changes" onclick="checkCatForm();"   />
      &nbsp;&nbsp;
      <input name="btnCancel" type="button" id="btnCancel" value="Cancel" onclick="window.location.href='files.php';"   />
    </p>
	</form>    
<?php } else { ?>
		<br />
		<div align="center" class="formTitle">List of Files in Rules &amp; Regulations </div>
        <table width="70%" border="0" align="center" cellpadding="5" cellspacing="1" class="text" >
      <tr>
        <td colspan="3" align="right"><input name="btnAddType" type="button" id="btnAddType" value="Upload New File"  onClick="javascript:window.location.href = 'files.php?a=add'" /></td>
      </tr>
      <tr align="center" id="listTableHeader"> 
        <td width="231">Name</td>
		<td width="229">File</td>
        <td width="74">Action</td>
      </tr>
    <?php
    // for paging how many rows to show per page

$query = "SELECT * FROM files where page=13";
$result = Query ($query);
if(mysql_num_rows($result)){
while ($row = mysql_fetch_array($result)) 
   {
	$id = $row['id'];
	$name = $row['name'];
	$file = $row['pdffile'];
    ?>
        <tr bgcolor="#CCCCCC"> 
          <td><?php echo $name; ?></td>
		  <td><a href="../images/files/<?=$file?>" target="_blank"><?=$file?></a></td>
          <td align="center">
            <a href="files.php?a=edit&id=<?php echo $id; ?>" title="Modify File"><img src='css/icon_edit.gif' border='0' alt='Modify Blog Category' /></a> &nbsp; 
            <a href="files.php?a=delete&id=<?php echo $id; ?>" onclick="return confirm_msg('Are you sure you want to delete this file?');" title="Delete File"><img src='css/icon_delete.gif' border='0' alt='Delete Blog Category' /></a></td>
        </tr>
    <?php
      //} // end while
    ?>
       
    <?php	
      } }else {
    ?>
        <tr> 
        <td colspan="2" align="center">No Files Yet</td>
        </tr>
    <?php
    }
    ?>
    </table>
    <br />
	<?php
    }
  ?>
	</td>
  </tr>
</table>
	</td>
  </tr>
  <tr><td valign="top" style="background-image: url(../images/ftr-bg.jpg); background-repeat: repeat-x; height:70px ">
	<table width="953" align="center"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="190" height="23" align="left" valign="middle" class="ftr">Copyright � 2009 Sunshine School</td>
    <td width="659" align="center" valign="middle" class="ftr2"></td>
    <td width="104" align="right" valign="middle"class="ftxt1"></td>
  </tr>
</table>
	</td></tr>
</table>
</td>
</tr>

</table>
</body>
</html>
