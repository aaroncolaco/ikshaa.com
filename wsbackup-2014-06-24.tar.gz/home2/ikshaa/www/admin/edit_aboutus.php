<?php 
require_once "include/functions.php";
require_once "include/functions.inc.php";
sessionCheck();
$_SESSION[$SESSION] = $_SERVER['REQUEST_URI'];
//$_SESSION[$SESSION] = $_SERVER['REQUEST_URI'];




if( isset($_POST["content"])) {

	 $uid = escape($_POST['hidPage']);
	$pageContent = escapestring($_POST['txtarContent']);
	$pageContent2 = escapestring($_POST['txtarContent2']);
	$query = "UPDATE `pages` SET `page_content`='".$pageContent."',`page_content2`='".$pageContent2."' WHERE `page_id` = '".$uid."' ";
	$row = Query($query) or die("Unkown Error");

$msg= "<center><font color='#941623'><b>Data has been Saved Succesfully!!</b></font></center><br><br><br>";	
echo  "<META HTTP-EQUIV=\"Refresh\" Content=\"1;URL=admin.php\">";

}

 
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Ishkaa : Admin Panel</title>
<link href="../css/style.css" type="text/css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet">
 <link href="fck/styles.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="fck/fckeditor.js"></script>

  <style type="text/css">
<!--
.style2 {
	color: #006600;
	font-size: 24px;
}
.style3 {font-size:12px; color: #FEE181; font-family: Arial;}

-->


  </style>
   <!--[if IE 6]>
<style type="text/css">
body,img, div, h1, h2, h3, h4 { 
	behavior: url(iepngfix.htc);
}
</style>
<![endif]-->
</head>

<body style="margin:0px;">
<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr valign="top">
<td valign="top" width="971">
<table width="971" height="421" border="0" cellpadding="0" cellspacing="0">
  <tr valign="top">
    <td  align="center" valign="top" class="hr1">
	
	</td>
  </tr>
  <tr valign="top" >
    <td valign="top">
	  <table width="970" border="0" cellpadding="0" cellspacing="0" >
	  <tr><td colspan="2"><div align="left" style=" margin-left:250px; "><img src="../images/logo.png"></div>
	  </td>
	  </tr>
<tr><td colspan="2"  height="13" ></td></tr>
  <tr style=" background-color:#907747">
    <td width="160" valign="top" align="center" style="padding-top:30px; padding-bottom:8px " ><? include('menu.php');?></td>
    <td width="803" align="center" valign="top" >
    <p>&nbsp;</p><p><? echo $msg;?></p>
	<?
$query = "SELECT * FROM pages WHERE page_id ='2' ";
$row = Query($query) or die("Unkown Error");			
if( @mysql_num_rows($row) ) {
	$result = mysql_fetch_assoc($row);
	$pageId = $result['page_id'];
	$pageName = $result['page_name'];
	$pageContent = escape($result['page_content']);
	$pageContent2 = escape($result['page_content2']);
	//$pageContent = $result->page_content;

	?>
    
<div align="right" style="padding-right:65px; padding-bottom:0px; ">
      <input name="btnAddType" type="button" id="btnAddType" value="New Photo"  onClick="javascript:window.location.href = 'gallery.php?a=add&page_id=<?=$pageId?>'" />
      <input name="btnAddType" type="button" id="btnAddType" value="View Photos"  onClick="javascript:window.location.href = 'gallery.php?page_id=<?=$pageId?>'" />
    </div>
<form id="form1" name="form1" method="post" action="edit_aboutus.php?action=edit&id=<?php echo $pageId; ?>">
	<div align="left" style=" margin-top:4px;" class="style3"><b>MODIFY CONTENT</b></div>
<br>

			<link href="fck/styles.css" rel="stylesheet" type="text/css" />
            <script type="text/javascript" src="fck/fckeditor.js"></script>
            <script type="text/javascript">
              <!--
				var oFCKeditor = new FCKeditor( 'txtarContent' ) ;
              oFCKeditor.BasePath	= 'fck/' ;
              oFCKeditor.Height	= 220;
							oFCKeditor.ToolbarSet = 'Custom' ;
				oFCKeditor.Value	= '<? echo $pageContent;?>' ;
              oFCKeditor.Create() ;
              //-->
            </script>
            <script type="text/javascript">
              <!--
				var oFCKeditor = new FCKeditor( 'txtarContent2' ) ;
              oFCKeditor.BasePath	= 'fck/' ;
              oFCKeditor.Height	= 220 ;
							oFCKeditor.ToolbarSet = 'Custom' ;
				oFCKeditor.Value	= '<? echo $pageContent2;?>' ;
              oFCKeditor.Create() ;
              //-->
            </script>
  <input type="hidden" name="hidPage" value="<?=$pageId;?>"  />

  <input type="submit" name="content" value="Update" />
  <input name="btnCancel" type="button" id="btnCancel" value="Cancel" onClick="window.location.href='admin.php';">
</form>

<?
}
?>
<p>&nbsp;</p>
	</td>
  </tr>
</table>
	</td>
  </tr>
  <tr ><td height="22" valign="top">
	<table width="" align="center"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="" align="center" valign="middle" class="footer">&nbsp;Copyright &copy; Ikshaa. All Rights Reserved&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Served by <a class="ftr" target="_blank" href="http://www.goacyberworks.com/">GCW</a>

    </td>

  </tr>
</table>
	</td></tr>
</table>
</td>
</tr>

</table>
</body>
</html>
