<?php
include dirname(__FILE__)."/config.php";
require_once('mysql.class.php');

/* Session Start for Admin */
function sessionStart($user,$pass){
	global $SESSION,$db;
	$query ="SELECT * FROM `admin` WHERE username = '".escape($user)."' AND password ='".md5(escape($pass))."' ";
	$row = Query($query);
	if(@mysql_num_rows($row)) {
		$result = mysql_fetch_assoc($row);
		session_start();
		$_SESSION[$SESSION] = 1;
		$_SESSION['userId'] = $result['id'];
		$_SESSION['time'] = time();
		header("Location: admin.php");
	} else {
		$error= " <p style='color:#FF0000'>User Login Failed</p>";
		return $error;
	}
}
/* Session Check and Time out for Admin */
function sessionCheck(){
	global $SESSION,$sessionTimeout,$db;
	session_start();
	if( !isset($_SESSION[$SESSION]) ) {
		header("location: index.php");
	}else{
		$oldTime = $_SESSION['time'];
		$now = time();
		$timeDiff = $now - $oldTime;
		if($timeDiff >$sessionTimeout){
			sessionDestroy();
		}else{
			$_SESSION['time']=time();
		}
	}
}
/* Logout*/
function sessionDestroy(){
	global $SESSION;
	session_start();
	unset($_SESSION[$SESSION]);
	unset($_SESSION['userId']);
	unset($_SESSION['time']);
	session_destroy();
	header("location: index.php");
}