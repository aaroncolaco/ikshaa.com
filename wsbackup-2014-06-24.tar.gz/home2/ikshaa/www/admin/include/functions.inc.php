<?php
//function to escape special characters in a string for use in a SQL statement
function escapestring($text) {
if (!get_magic_quotes_gpc()) {
		$text = mysql_real_escape_string($text);
	}
	return $text;
}
// function to escape single quote in a string for use in a SQL statement
function escapequote($text) {
	return ereg_replace("(')", "&#39;", $text);
}


/*
	Upload an image and return the uploaded image name 
*/
function uploadImage($inputName, $uploadDir, $propertyId) {
	$image = $_FILES[$inputName];
	$imagePath = '';
	
	// if a file is given
	if (trim($image['tmp_name']) != '') {
		$ext = substr(strrchr($image['name'], "."), 1); //$extensions[$image['type']];

		// generate a random new file name to avoid name conflict
		$imagePath = time() . "_pid" . $propertyId. "_". strtolower($image['name']);
		
		list($width, $height, $type, $attr) = getimagesize($image['tmp_name']); 

		// make sure the image width does not exceed the maximum allowed width
		if (LIMIT_IMAGE_WIDTH && $width >= IMAGE_WIDTH) {
			$result = createThumbnail($image['tmp_name'], $uploadDir . $imagePath, IMAGE_WIDTH);
			$imagePath = $result;
		} else {
			$result = move_uploaded_file($image['tmp_name'], $uploadDir . $imagePath);
		}	
		
		if ($result) {
			// create thumbnail
			$result = createThumbnail($uploadDir . $imagePath, $uploadDir ."thumb/" . $imagePath, THUMBNAIL_WIDTH);
			
			// create thumbnail failed, delete the image
			if (!$result) { 
				unlink($uploadDir . $imagePath);
				$imagePath = '';
			}
		} else {
			// the product cannot be upload / resized
			$imagePath = '';
		}
	}

	return $imagePath;
}

/*
	Create a thumbnail of $srcFile and save it to $destFile. The thumbnail will be $width pixels.
*/
function createThumbnail($srcFile, $destFile, $width, $quality = 100) {
	$thumbnail = '';
	
	if (file_exists($srcFile) && isset($destFile)) {
		$size = getimagesize($srcFile);
		/*$w = number_format($width, 0, ',', '');
		$h = number_format(($size[1] / $size[0]) * $width, 0, ',', '');*/
		$w = $h = number_format($width, 0, ',', '');
		
		$thumbnail =  copyImage($srcFile, $destFile, $w, $h, $quality);
	
	}
	
	// return the thumbnail file name on sucess or blank on fail
	return basename($thumbnail);
}

/*
	Copy an image to a destination file. The destination image size will be $w X $h pixels
*/
function copyImage($srcFile, $destFile, $w, $h, $quality = 75) {
	$tmpSrc = pathinfo(strtolower($srcFile));
	$tmpDest = pathinfo(strtolower($destFile));
	$size = getimagesize($srcFile);

	if ($tmpDest['extension'] == "gif" || $tmpDest['extension'] == "jpg") {
		$destFile = substr_replace($destFile, 'jpg', -3);
		$dest = imagecreatetruecolor($w, $h);
		imageantialias($dest, TRUE);
	} elseif ($tmpDest['extension'] == "png") {
		$dest = imagecreatetruecolor($w, $h);
		imageantialias($dest, TRUE);
	} else {
		return false;
	}

	switch($size[2]) {
		case 1:       //GIF
			$src = imagecreatefromgif($srcFile);
			break;
		case 2:       //JPEG
			$src = imagecreatefromjpeg($srcFile);
			break;
		case 3:       //PNG
			$src = imagecreatefrompng($srcFile);
			break;
		default:
			return false;
			break;
	}

	imagecopyresampled($dest, $src, 0, 0, 0, 0, $w, $h, $size[0], $size[1]);

	switch($size[2]) {
		case 1:
		case 2:
			imagejpeg($dest,$destFile, $quality);
			break;
		case 3:
			imagepng($dest,$destFile);
	}
	return $destFile;
}
/**************************
	Paging Functions
***************************/
function getPagingQuery($sql, $itemPerPage = 10) {
	if (isset($_GET['page']) && (int)$_GET['page'] > 0) {
		$page = (int)$_GET['page'];
	} else {
		$page = 1;
	}
	
	// start fetching from this row number
	$offset = ($page - 1) * $itemPerPage;
	return $sql . " LIMIT $offset, $itemPerPage";
}
/*
	function to bulid url for paging
*/
function build_url($filename, $key, $value){
  $values = array();
  $query_str = array();
  //get the query string arguments and store them in the $values array
  parse_str($_SERVER['QUERY_STRING'], $values);
  //loop through the $values array and add the appropriate keys to the query string
  foreach ($values as $k=>$v) {
    //IF, though, a key in the existing query string matches the same key
    //we're trying to add, ignore it, since we'll add it manually in a moment
    //This prevents having multiples of the same keys
    if ($k!=$key) {
      $query_str[] = "{$k}={$v}";
    }
  }
  //add in our new key and value
	if($key && $value)
		$query_str[] = "{$key}={$value}";
  //reconstruct the full URL using the implode() function to piece together all
  //the query string values in the $query_string array, joining them together with "&"  
  return "$filename?".implode("&amp;", $query_str);
}
/*
	Get the links to navigate between one result page to another.
*/
function getPaging($filename, $sql, $itemPerPage) {
	$result = Query($sql);
	$totalResults = dbNumRows($result);
	$totalPages = ceil($totalResults / $itemPerPage);
	
	// how many link pages to show
	$numLinks = 10;

	// create the paging links only if we have more than one page of results
	if ($totalPages > 1) {
		if (isset($_GET['page']) && (int)$_GET['page'] > 0) {
			$pageNumber = (int)$_GET['page'];
		} else {
			$pageNumber = 1;
		}
		
		// print 'previous' link only if we're not on page one
		if ($pageNumber > 1) {
			if ($pageNumber != 1) {
				$prev = " <a href='".build_url($filename, "page", $pageNumber-1)."' class='paging'>[Prev]</a> &nbsp;&nbsp;";
			}	
			$first = " <a href='".build_url($filename, "page", 1)."' class='paging'>[First]</a> &nbsp;&nbsp;";
		} else {
			$first = ''; // we're on page one, don't show 'first page' link
			$prev  = ''; // nor 'previous' link 
		}
	
		// print 'next' link only if we're not on the last page
		if ($pageNumber < $totalPages) {
			$next = "&nbsp;&nbsp; <a href='".build_url($filename, "page", $pageNumber+1)."' class='paging'>[Next]</a> ";
			$last = "&nbsp;&nbsp; <a href='".build_url($filename, "page", $totalPages)."' class='paging'>[Last]</a> ";
		} else {
			$next = ''; // we're on the last page, don't show 'next' link
			$last = ''; // nor 'last page' link
		}

		$start = $pageNumber - ($pageNumber % $numLinks) + 1;
		$end   = $start + $numLinks - 1;		
		$end   = min($totalPages, $end);
		
		$pagingLink = array();
		for($page = $start; $page <= $end; $page++)	{
			if ($page == $pageNumber) {
				$pagingLink[] = " <span class='page'><strong>$page</strong></span> ";   // no need to create a link to current page
			} else {
				$pagingLink[] = " <a href='".build_url($filename, "page", $page)."' class='paging'>$page</a> ";
			}
		}
		
		$pagingLink = implode('&nbsp;&nbsp; <span class="page">|</span>&nbsp;&nbsp;', $pagingLink);
		
		// return the page navigation link
		$pagingLink = $first . $prev . $pagingLink . $next . $last;
	}
	
	return $pagingLink;
}


?>