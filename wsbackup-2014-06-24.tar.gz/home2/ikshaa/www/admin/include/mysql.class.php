<?php
/* Mysql Connection */
function connect(){
	global $db_server,$db_user,$db_pass,$database;//Global Values from the config.php
	$conn = @mysql_connect($db_server,$db_user,$db_pass) or die("Connection to Database Server Failed");
	@mysql_select_db($database) or die("Database Selection Failed");
	return $conn;
}

/* MYSQL QUERY FUNCTION */ 
function Query($sqlString){
	$conn = connect();
	$rows = @mysql_query($sqlString,$conn);
	@mysql_close($conn);
	return $rows;
}
function escape($dirtyStr){
	$conn = connect();
	if(function_exists('mysql_real_escape_string'))
		return @mysql_real_escape_string($dirtyStr, $conn);
	else
		# Nope, use the old one.
		return @mysql_escape_string($dirtyStr);
}




?>