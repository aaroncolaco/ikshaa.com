<?php
//$db_server = "web805.linux-hosting.com"; //Database server
//$db_user = "resortrio";				//Database user name
//$db_pass = "gcwgoa"; //Database server password
//$database = "resortrio"; //Database Name

//$filePath = $_SERVER['DOCUMENT_ROOT']."/resortrio"; //Complete File Path on the webserver Without trailing slash for FCK EDITOR

/* Default Session Time out */
$sessionTimeout = 3600; //Session time out should be specified in SECONDS;
$SESSION = "sunshine";

$upload_file_size = 7; // In MB

?>