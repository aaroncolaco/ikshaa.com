/*
Strip whitespace from the beginning and end of a string
Input : a string
*/
function trim(str) {
	return str.replace(/^\s+|\s+$/g,'');
}

/*
Make sure that textBox only contain number
*/
function checkNumber(textBox) {
	while (textBox.value.length > 0 && isNaN(textBox.value)) {
		textBox.value = textBox.value.substring(0, textBox.value.length - 1)
	}
	
	textBox.value = trim(textBox.value);
}

/*
	Check if a form element is empty.
	If it is display an alert box and focus on the element
*/
function isEmpty(formElement, message) {
	formElement.value = trim(formElement.value);
	
	_isEmpty = false;
	if (formElement.value == '') {
		_isEmpty = true;
		alert(message);
		formElement.focus();
	}
	
	return _isEmpty;
}

/*
	Make sure that textBox has proper email address
*/
function isNotEmail(formElement, message) {
	formElement.value = trim(formElement.value);
	
	_isNotEmail = false;
	if((/^[a-zA-Z0-9._-]+@([a-zA-Z0-9.-]+\.)+[a-zA-Z]{2,5}$/).exec(formElement.value)==null){
		_isNotEmail = true;
		alert(message);
		formElement.focus();
	}
	
	return _isNotEmail;
}

/*
	Set one value in combo box as the selected value
*/
function setSelect(listElement, listValue) {
	for (i=0; i < listElement.options.length; i++) {
		if (listElement.options[i].value == listValue)	{
			listElement.selectedIndex = i;
		}
	}	
}

/*
	File input file function
*/
function onkeyPress(e) {
	var key = window.event ? e.keyCode : e.which;
	if (key == 13)
		StartClick();
		
	e.cancelBubble = true;
	e.returnValue = false;
	return false;
}

/*
	Delete confirm alert message
*/
function confirm_msg(msg) {
	var flg = confirm(msg); 
	if (flg) return true;		// Output when OK is clicked
	else return false;			// Output when Cancel is clicked
}

//js function to loads new captcha image
function new_captcha_img(captcha_img) {
	if (document.getElementById) {
		// extract image name from image source (i.e. cut off randomness)
		thesrc = document.getElementById(captcha_img).src;
		thesrc = thesrc.substring(0,thesrc.lastIndexOf(".")+4);
		// add (random) to prevent browser/isp caching
		document.getElementById(captcha_img).src = thesrc+"?"+Math.round(Math.random()*100000);
	} else {
		alert("Sorry, cannot autoreload image\nSubmit the form and a new image will be loaded");
	}
}