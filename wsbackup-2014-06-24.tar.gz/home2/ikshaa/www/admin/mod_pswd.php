<?php 
require_once "include/functions.php";
sessionCheck();
$_SESSION[$SESSION] = $_SERVER['REQUEST_URI'];

$query = "SELECT username FROM admin WHERE id ='". $_SESSION['userId']."' ";
$row = Query($query) or die("Unkown Error");
if( @mysql_num_rows($row) ) {
	$result = mysql_fetch_assoc($row);
	$user = $result['username'];
}

if( isset($_POST['edit']) ) {
	$user = addslashes($_POST['txtuser']);
	$pass = addslashes($_POST['txtpass']);
	$cnf_pass = addslashes($_POST['txtcnfpass']);
	if( $pass == $cnf_pass){
		if( $user && $pass ) {
			$query = "UPDATE `admin` SET `username`='$user',`password`='".md5(escape($pass))."'";
		} elseif( $user ) {
			$query = "UPDATE `admin` SET `user_name`='$user'";
		}
		$row = Query($query) or die("Unkown Error");
		if( $row ){
			$msg = "<br><div class='errorMessage'> Your password has been updated successfully</div>";
		} else { 
			$msg = "<br><div class='errorMessage'> Password Updation Failed</div>";
		}
	} else {
		$msg = "<br><div class='errorMessage'>Password Missmatch</div>";
	}
}

 
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Ishkaa : Admin Panel</title>
<link href="../css/style.css" type="text/css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet">
  <script>
  function val()
  {
  if(document.form1.txtpass.value=="")
  {
  alert("New Password cannot be blank");
  document.form1.txtpass.focus();
  return false;
  }
  if(document.form1.txtcnfpass.value=="")
  {
  alert("Confirm Password cannot be blank");
  document.form1.txtcnfpass.focus();
  return false;
  }
  else return true;
  }
  </script>
   <!--[if IE 6]>
<style type="text/css">
body,img, div, h1, h2, h3, h4 { 
	behavior: url(iepngfix.htc);
}
</style>
<![endif]-->
  <style type="text/css">
<!--
.style2 {
	color: #006600;
	font-size: 24px;
}
.style3 {font-size:12px; color: #FEE181; font-family: Arial;}

-->


  </style>
</head>

<body style="margin:0px;">
<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr valign="top">
<td valign="top" width="971">
<table width="971" height="421" border="0" cellpadding="0" cellspacing="0">
  <tr valign="top">
    <td  align="center" valign="top" class="hr1">
	
	</td>
  </tr>
  <tr valign="top" >
    <td valign="top">
	  <table width="970" border="0" cellpadding="0" cellspacing="0" >
	  <tr><td colspan="2"><div align="left" style=" margin-left:250px; "><img src="../images/logo.png"></div>
	  </td>
	  </tr>
<tr><td colspan="2"  height="13" ></td></tr>
  <tr style=" background-color:#907747">
    <td width="160" valign="top" align="center" style="padding-top:30px; padding-bottom:8px " ><? include('menu.php');?></td>
    <td width="803" align="center" valign="top" >
		<div align="left" style=" margin-top:4px;" class="style3"><b>MODIFY PASSWORD</b></div>
        <br>
<p><? echo $msg;?></p>
	
	<form id="form1" name="form1" method="post" action="mod_pswd.php">
  <table width="457" height="121" cellpadding="5" cellspacing="1" class="entryTable" border="0">
    <tr>
      <td width="150" class="label">Current Password : </td>
      <td width="242" class="content"><input readonly type="text" name="txtuser" id="txtuser" value="<?=$user;?>" /></td>
    </tr>
    <tr>
      <td  valign="middle" class="label">Password :</td>
      <td class="content"><input type="password" name="txtpass" id="txtpass" /></td>
    </tr>
    <tr>
      <td  valign="middle" class="label">Confirm Password :</td>
      <td class="content"><input type="password" name="txtcnfpass" id="txtcnfpass" /></td>
    </tr>
  </table>
  
  <p>
    <label>
    <input type="submit" name="edit" id="edit" value="Change" onClick="return val()" />
    </label>
  </p>
</form>
<p>&nbsp;</p>
	</td>
  </tr>
</table>
	</td>
  </tr>
<tr ><td height="22" valign="top">
	<table width="" align="center"  border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td width="" align="center" valign="middle" class="footer">&nbsp;Copyright &copy; Ikshaa. All Rights Reserved&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Served by <a class="ftr" target="_blank" href="http://www.goacyberworks.com/">GCW</a>

    </td>

  </tr>
</table>
	</td></tr>
</table>
</td>
</tr>

</table>
</body>
</html>
