<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?
include("include/config.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ikshaa : Facilities & Location</title>
<link href="css/style.css" type="text/css" rel="stylesheet">
<link href="css/style2.css" type="text/css" rel="stylesheet">


<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
 
$(document).ready(function(){
 
	$(document).ready(function () {
		$('#page_effect').fadeIn(2000);
      });
 
});
</script>
<!--[if IE 6]>
<style type="text/css">
body,img, div, h1, h2, h3, h4 { 
	behavior: url(iepngfix.htc);
}
</style>
<![endif]-->

<style>


html, body{
	padding: 0px;
	margin: 0px;
}

body{
background:url(images/test.jpg) no-repeat fixed center top;
}

/* using the child selector (which IE<7 doesn't recognise) to hide the following body css from IE6 and earlier */
html>body {
	background: url(images/test.jpg) no-repeat fixed center top #907747;
	

}

#footer {
	position:absolute;
	bottom:0;
	width:100%;
	height:49px;background-color:#826839;
	/*z-index:999;*/
}

html>body #footer{position:fixed}/* for moz/opera and others*/

#footer-inner {
	height: 27px;
	background-color:#826839;
}





p {margin-top:0}


#inner {
	padding: 0px;
}

#outer>#contain-all>#inner { /* child selector hides from IE<7 */
	/* 
	commented-out the following to prevent #inner from obscuring the navigation 
	menu in IE7.
	Why was #inner obscuring #nav anyway? And why did I give #inner a background
	colour since removing this doesn't seem to break anything in Firefox? 
	*/
	
}

#outer>#contain-all>#inner>#content {
	/* 
	commented-out the following to prevent weird behaviour with the footer image
	in IE7.
	Why did I put the background image in #content in the first place, since 
	removing this doesn't seem to break anything in Firefox? 
	*/
/*	
	background-repeat: no-repeat;
	background-position: bottom right;
	background-attachment: fixed;*/
}





</style>
<!--[if lte IE 6]>

	<link href="css/ie6.css" rel="stylesheet" type="text/css" />

<![endif]-->
<!--[if IE 7]>

	<link href="css/ie7.css" rel="stylesheet" type="text/css" />

<![endif]-->
</head>

<body id="body_fac">
<div id="outer" style="margin-top:0px; top:0;">
<table width="920"  align="center" border="0" cellspacing="0" cellpadding="0">
  <tr valign="top">
    <td width="865" valign="top"><div align="center" style="margin-top:50px;"><img src="images/logo.png" border="0" usemap="#Map"/ ></div></td>
  </tr>
  <tr valign="top">
  <td class="text"  valign="top">
  
 <div style=" padding-left:25px; padding-right:25px; margin-top:20px;">
  <!--<div class="header">Facilities & Location</div> -->
<? $query1="SELECT * FROM pages where page_id='3'";
$result1 = mysql_query ($query1);
if(mysql_num_rows($result1))
{
while ($row1 = mysql_fetch_array($result1)) {
   ?>
	<?=$row1['page_content']?>
<? 
}
}
else
{
echo "No data available";
}
?>
</div>

  </td>
  </tr>
</table>
<div style="height:50px;"></div>



</div>

<div id="footer">
<div id="footer-inner">	
<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr><td valign="top" colspan="3"><div id="nav_bar">
	<ul id="nav">
		<li id="nav_hom"><a href="index.php">Home</a></li>
        <li class="sep">|</li>
		<li id="nav_abt"><a href="about_us.php">About Ikshaa</a></li>
		<li class="sep">|</li>
        <li id="nav_fac"><a href="facilities_and_location.php">Facilities & Location</a></li>
		 <li class="sep">|</li>
        <li id="nav_gal"><a href="gallery.php">Photo Gallery</a></li>
        <li class="sep">|</li>
        <li id="nav_con"><a href="contact_us.php">Contact Us</a></li>
		</ul>
	</div>
	</td></tr>
    <tr valign="top">
    <td valign="top"></td>
    <td align="center" valign="middle" width="950" class="footer">Copyright &copy; Ikshaa. All Rights Reserved
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Served by <a class="ftr" target="_blank" href="http://www.goacyberworks.com/">GCW</a>
    </td>
    <td valign="top"></td>
  </tr></table>
</div></div>


<map name="Map" id="Map"><area shape="rect" coords="3,3,244,92" href="index.php" />
</map></body>
</html>
