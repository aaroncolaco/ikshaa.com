<?
//$dbhost = "localhost";
//$dbuser = "root";
//$dbpass = "";
//$dbname = "ishkaa";

$dbhost = "66.199.235.34";
$dbuser = "ikshaa1";
$dbpass = "gcwgoa";
$dbname = "ikshaa1";

mysql_connect($dbhost, $dbuser, $dbpass) or die("Cannot connect to the database because: ".mysql_error());
mysql_select_db($dbname) or die("Cannot select the database '$dbname' because: ".mysql_error());
?>
