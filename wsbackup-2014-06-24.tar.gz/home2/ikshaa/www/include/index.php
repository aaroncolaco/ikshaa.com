<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title> Villa Goa|Luxury villa in Goa | holiday villas goa | Villas in south goa | boutique resorts in goa </title>
    <meta name="description" content="Luxury Villa in Goa. Ikshaa, vllas in south goa offers best among boutique resorts and  holiday villas in goa.holiday home goa india portuguese villa hotel luxury heritage colonial house">
    <meta name="keywords" content="luxury villa goa,Luxury villa in Goa,holiday villas goa,Villas in south goa,boutique resorts in goa heritage mansion goa, South goa, loutolim, home stay in goa, bed and breakfast goa, luxury accommodation goa, resort in goa, resort, holiday home goa, india, portuguese villa, hotel, luxury, heritage, colonial house">
    <meta name="copyright" content="Copyright Ikshaa - 2010">
    <meta name="author" content="Ikshaa">
    <meta name="email" content="nyaragoa@gmail.com">
    <meta name="Distribution" content="Global">
    <meta name="Rating" content="General">
    <meta name="Robots" content="INDEX,FOLLOW">
    <meta name="Revisit-after" content="31 Days">
<?
include("include/config.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" type="text/css" rel="stylesheet">
<link href="css/style2.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="highslide/highslide-with-gallery.js"></script>
<link rel="stylesheet" type="text/css" href="highslide/highslide.css" />
<script type="text/javascript">
	hs.graphicsDir = 'highslide/graphics/';
	hs.align = 'center';
	hs.transitions = ['expand', 'crossfade'];
	 hs.outlineType = 'outer-glow';
    hs.wrapperClassName = 'outer-glow';
	hs.fadeInOut = true;
	//hs.dimmingOpacity = 0.75;

	// Add the controlbar
	if (hs.addSlideshow) hs.addSlideshow({
		//slideshowGroup: 'group1',
		interval: 8000,
		repeat: false,
		useControls: true,
		fixedControls: 'fit',
		overlayOptions: {
			opacity: .6,
			position: 'bottom center',
			hideOnMouseOut: true
		}
	});
</script>
<!--[if IE 6]>
<style type="text/css">
body,img, div, h1, h2, h3, h4 { 
	behavior: url(iepngfix.htc);
}
</style>
<![endif]-->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript">
 
$(document).ready(function(){
 
	$(document).ready(function () {
		$('#page_effect').fadeIn(2000);
      });
 
});
</script>
<!--[if lte IE 6]>

	<link href="css/ie6.css" rel="stylesheet" type="text/css" />

<![endif]-->
<!--[if IE 7]>

	<link href="css/ie7.css" rel="stylesheet" type="text/css" />

<![endif]-->
</head>

<body id="body_hom"><div id="page_effect" style="display: none;">
<table width="920"  align="center" border="0" cellspacing="0" cellpadding="0">
  <tr valign="top">
    <td width="865" height="132" valign="top"><div align="center" style="margin-top:50px; margin-bottom:30px;"><img src="images/logo.png" alt="villa goa, villa in goa" border="0" usemap="#Map"/ ></div></td>
  </tr>
    <tr valign="top">
  <td valign="top" align="center">
  <div align="center">
 <?
$query="SELECT * FROM gallery where page_id='1'";
$result = mysql_query ($query);
$i = 0;
if(mysql_num_rows($result))
{
echo"<table align='center' cellspacing='0' cellpadding='0'>";

while ($row = mysql_fetch_array($result)) {

  if ($i % 5 == 0)
  echo"<tr valign='top'>";
  echo"<td>";
   ?>
	
	    <div class="highslide-gallery" style="margin:0px 30px 15px 5px;">
<a href="images/gallery/<?=$row['image']?>"class="highslide" onclick="return hs.expand(this)"><img alt="<?=$row['id']?>" src="images/gallery/thumb/<?=$row['image']?>" border="0" title="Click to enlarge"/></a>

</div>
<? 
$i++;  
} 

echo"</tr>";
echo"</table>";
}
else
{
echo "<span class='text1b'>No data available</span>";
}
?>
</div>
  </td>
  </tr>
  <tr valign="top">
  <td class="text" >
  
  <div style=" padding-left:25px; padding-right:25px; margin-top:20px;">
  <div class="header">Welcome to ikshaa</div><br />
<? $query1="SELECT * FROM pages where page_id='1'";
$result1 = mysql_query ($query1);
if(mysql_num_rows($result1))
{
while ($row1 = mysql_fetch_array($result1)) {
   ?>
	<?=$row1['page_content']?> | <a href="about_us.php" class="txt-l">More</a>
<? 
}
}
else
{
echo "No data available";
}
?>
</div>

  </td>
  </tr>
</table>
<? include("include/footer.php");?>

<map name="Map" id="Map"><area shape="rect" coords="3,3,244,93" href="index.php" />
</map>
</div>
</body>
</html>
