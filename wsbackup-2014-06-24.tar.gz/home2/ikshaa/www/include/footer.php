<div id="footer">
<div id="footer-inner">	
<table align="center" cellpadding="0" cellspacing="0" border="0">
<tr><td valign="top" colspan="3"><div id="nav_bar">
	<ul id="nav">
		<li id="nav_hom"><a href="index.php">Home</a></li>
        <li class="sep">|</li>
		<li id="nav_abt"><a href="about_us.php">About ikshaa</a></li>
		<li class="sep">|</li>
        <li id="nav_fac"><a href="facilities_and_location.php">Facilities & Location</a></li>
		 <li class="sep">|</li>
        <li id="nav_gal"><a href="gallery.php">Photo Gallery</a></li>
         <li class="sep">|</li>
        <li id="nav_con"><a href="contact_us.php">Contact Us</a></li>
         <li class="sep">|</li>
        <li id="nav_con"><a href="http://ikshaa.com/">villa Goa</a></li>
		</ul>
	</div>
	</td></tr>
    <tr valign="top">
    <td valign="top"></td>
    <td align="center" valign="middle" width="950" class="footer">Copyright &copy; Ikshaa. All Rights Reserved
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Served by <a class="ftr" target="_blank" href="http://ikshaa.com/heritagevillagoa.html">GCW</a>    </td>
    <td valign="top"></td>
  </tr></table>
</div></div>