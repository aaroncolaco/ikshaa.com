#!/bin/sh
# CLICKABLES_DIR should be the directory where the Clickables CGI's will be
# placed.  If it does not exist, it is created.
#
# OWNER is the owner of the CGI's.
#
# GROUP ought to be the name of a web group, but if that does not exist
# or the OWNER does not belong to it, make it what group he/she does
# belong to.  If they don't belong to a group, make it blank.
#
# DOCUMENT_ROOT should be the httpd root directory if OWNER's web pages are
# underneath it, or the root directory to their home html directory (for
# instance "/home/OWNER/public_html").  If your httpd gives this directory
# in the environment that it sets up for CGI's, it may be removed. Do not
# leave it blank!!!
#
# PERMS normally ought to be "ug+s".  Some programs need to have write     
# permissions to directories where they store files.  If they can't have  
# group setuid privileges, make it just "u+s", and if they can't have either,
# then whatever directory that they use must be writable by all (bad but
# necessary in this case).  Ask OWNER what directory this will be.

CLICKABLES_DIR=/web/ikshaa/shoppage
DOCUMENT_ROOT=/web/ikshaa
OWNER=ikshaa
GROUP=ikshaagrp
PERMS=ug+s

if [ ! -x $CLICKABLES_DIR ]; then
	mkdir $CLICKABLES_DIR
	chown $OWNER $CLICKABLES_DIR
	chgrp $GROUP $CLICKABLES_DIR
fi

chmod 664 license.txt

PROGS="cart"
chown $OWNER $PROGS
chgrp $GROUP $PROGS
chmod a+rwx,o-w $PROGS

#chmod $PERMS cart
cp -p cart $CLICKABLES_DIR/cart.cgi

cp -p license.txt $CLICKABLES_DIR
